import { TripData } from '../App';

export function parseSearchQuery(query: string): Partial<TripData> {
  const parsedData: Partial<TripData> = {};

  // Extract destination - look for city names or place names
  const destinationPatterns = [
    /(?:to|in|visit|going to|traveling to|trip to)\s+([A-Z][a-zA-Z\s]+?)(?:\s+(?:for|with|from|on|in|,|$))/i,
    /^([A-Z][a-zA-Z\s]+?)(?:\s+(?:for|with|from|on|in|trip|,))/,
  ];

  for (const pattern of destinationPatterns) {
    const match = query.match(pattern);
    if (match) {
      parsedData.destination = match[1].trim();
      break;
    }
  }

  // If no pattern matched, take the first capitalized word(s) as destination
  if (!parsedData.destination) {
    const capitalizedMatch = query.match(/([A-Z][a-zA-Z\s]+)/);
    if (capitalizedMatch) {
      const words = capitalizedMatch[1].trim().split(' ');
      parsedData.destination = words.slice(0, 3).join(' ').trim();
    }
  }

  // Extract number of travelers
  const travelerPatterns = [
    /(\d+)\s*(?:people|travelers|persons|adults|guests)/i,
    /for\s*(\d+)/i,
    /(\d+)\s*(?:of us)/i,
  ];

  for (const pattern of travelerPatterns) {
    const match = query.match(pattern);
    if (match) {
      parsedData.travelers = parseInt(match[1]);
      break;
    }
  }

  // Extract dates
  const monthNames = ['january', 'february', 'march', 'april', 'may', 'june',
                      'july', 'august', 'september', 'october', 'november', 'december'];
  const monthAbbr = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];

  // Look for date patterns like "May 1-3", "May 1 to May 3", "from May 1 to May 3"
  const dateRangePattern = new RegExp(
    `(${monthNames.join('|')}|${monthAbbr.join('|')})\\s*(\\d{1,2})(?:\\s*(?:-|to)\\s*(?:(${monthNames.join('|')}|${monthAbbr.join('|')})\\s*)?(\\d{1,2}))?`,
    'i'
  );

  const dateMatch = query.match(dateRangePattern);
  if (dateMatch) {
    const startMonth = monthNames.indexOf(dateMatch[1].toLowerCase());
    const startMonthFromAbbr = monthAbbr.indexOf(dateMatch[1].toLowerCase());
    const monthIndex = startMonth >= 0 ? startMonth : startMonthFromAbbr;

    if (monthIndex >= 0) {
      const startDay = parseInt(dateMatch[2]);
      const currentYear = new Date().getFullYear();
      const year = currentYear;

      parsedData.startDate = `${year}-${String(monthIndex + 1).padStart(2, '0')}-${String(startDay).padStart(2, '0')}`;

      if (dateMatch[4]) {
        let endMonth = monthIndex;
        if (dateMatch[3]) {
          const endMonthName = monthNames.indexOf(dateMatch[3].toLowerCase());
          const endMonthAbbr = monthAbbr.indexOf(dateMatch[3].toLowerCase());
          endMonth = endMonthName >= 0 ? endMonthName : endMonthAbbr;
        }
        const endDay = parseInt(dateMatch[4]);
        parsedData.endDate = `${year}-${String(endMonth + 1).padStart(2, '0')}-${String(endDay).padStart(2, '0')}`;
      }
    }
  }

  // Extract budget
  const budgetPatterns = [
    /\$\s*(\d+(?:,\d+)?)/,
    /budget\s*(?:of|is|:)?\s*\$?\s*(\d+(?:,\d+)?)/i,
    /(\d+(?:,\d+)?)\s*dollars?/i,
  ];

  for (const pattern of budgetPatterns) {
    const match = query.match(pattern);
    if (match) {
      parsedData.budget = parseInt(match[1].replace(/,/g, ''));
      break;
    }
  }

  // Extract travel type
  const travelTypeKeywords: Record<string, string> = {
    'leisure': 'leisure',
    'relax': 'leisure',
    'vacation': 'leisure',
    'holiday': 'leisure',
    'cultural': 'cultural',
    'culture': 'cultural',
    'museum': 'cultural',
    'history': 'cultural',
    'food': 'culinary',
    'culinary': 'culinary',
    'restaurant': 'culinary',
    'dining': 'culinary',
    'shopping': 'shopping',
    'shop': 'shopping',
    'adventure': 'adventure',
    'hiking': 'adventure',
    'outdoor': 'adventure',
    'business': 'business',
    'work': 'business',
    'conference': 'business',
  };

  const travelTypes: string[] = [];
  const queryLower = query.toLowerCase();

  for (const [keyword, type] of Object.entries(travelTypeKeywords)) {
    if (queryLower.includes(keyword) && !travelTypes.includes(type)) {
      travelTypes.push(type);
    }
  }

  if (travelTypes.length > 0) {
    parsedData.travelType = travelTypes;
  }

  // Extract accommodation preference
  const accomKeywords: Record<string, string> = {
    'hotel': 'hotel',
    'airbnb': 'Airbnb',
    'hostel': 'hostel',
  };

  for (const [keyword, type] of Object.entries(accomKeywords)) {
    if (queryLower.includes(keyword)) {
      parsedData.accommodation = type;
      break;
    }
  }

  // Extract dining preference
  const diningKeywords: Record<string, string> = {
    'local food': 'local',
    'local cuisine': 'local',
    'gourmet': 'gourmet',
    'fine dining': 'gourmet',
    'fast food': 'fast food',
  };

  for (const [keyword, type] of Object.entries(diningKeywords)) {
    if (queryLower.includes(keyword)) {
      parsedData.dining = type;
      break;
    }
  }

  // Extract transport preference
  const transportKeywords: Record<string, string> = {
    'public transport': 'public transport',
    'subway': 'public transport',
    'metro': 'public transport',
    'taxi': 'taxi',
    'uber': 'taxi',
    'rideshare': 'taxi',
    'rental car': 'rental car',
    'rent a car': 'rental car',
  };

  for (const [keyword, type] of Object.entries(transportKeywords)) {
    if (queryLower.includes(keyword)) {
      parsedData.transport = type;
      break;
    }
  }

  return parsedData;
}
