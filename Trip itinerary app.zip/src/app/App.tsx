import { useState } from 'react';
import { TripPlannerChat } from './components/TripPlannerChat';
import { TripItinerary } from './components/TripItinerary';
import { BookingSummary } from './components/BookingSummary';

export interface TripData {
  destination: string;
  travelers: number;
  startDate: string;
  endDate: string;
  travelType: string[];
  accommodation: string;
  dining: string;
  transport: string;
  budget?: number;
}

export interface GeneratedItinerary {
  tripData: TripData;
  days: DayPlan[];
  totalBudget: {
    accommodation: number;
    meals: number;
    transport: number;
    activities: number;
    flights: number;
    contingency: number;
    total: number;
  };
}

export interface DayPlan {
  day: number;
  date: string;
  morning: Activity;
  afternoon: Activity;
  evening: Activity;
  meals: {
    breakfast: MealPlan;
    lunch: MealPlan;
    dinner: MealPlan;
  };
  transport: TransportPlan[];
  dailyBudget: number;
}

export interface Activity {
  name: string;
  description: string;
  cost: number;
  duration: string;
  link?: string;
}

export interface MealPlan {
  restaurant: string;
  cuisine: string;
  estimatedCost: number;
  location: string;
  link?: string;
}

export interface TransportPlan {
  type: string;
  from: string;
  to: string;
  cost: number;
}

export default function App() {
  const [generatedItinerary, setGeneratedItinerary] = useState<GeneratedItinerary | null>(null);
  const [showBookingSummary, setShowBookingSummary] = useState(false);

  const handleGenerateItinerary = (tripData: TripData) => {
    const itinerary = generateMockItinerary(tripData);
    setGeneratedItinerary(itinerary);
    setShowBookingSummary(false);
  };

  const handleBackToPlanner = () => {
    setGeneratedItinerary(null);
    setShowBookingSummary(false);
  };

  const handleBookItinerary = () => {
    setShowBookingSummary(true);
  };

  const handleBackToItinerary = () => {
    setShowBookingSummary(false);
  };

  if (generatedItinerary && showBookingSummary) {
    return (
      <BookingSummary
        itinerary={generatedItinerary}
        onBack={handleBackToItinerary}
      />
    );
  }

  if (generatedItinerary) {
    return (
      <TripItinerary
        itinerary={generatedItinerary}
        onBack={handleBackToPlanner}
        onBookItinerary={handleBookItinerary}
      />
    );
  }

  return <TripPlannerChat onGenerateItinerary={handleGenerateItinerary} />;
}

function generateMockItinerary(tripData: TripData): GeneratedItinerary {
  const startDate = new Date(tripData.startDate);
  const endDate = new Date(tripData.endDate);
  const numDays = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)) + 1;

  const days: DayPlan[] = [];

  const destinationData: Record<string, any> = {
    'New York City': {
      activities: [
        { name: 'Central Park', description: 'Explore the iconic urban park', cost: 0, duration: '2-3 hours' },
        { name: 'Museum of Modern Art', description: 'World-class modern art museum', cost: 30, duration: '2-3 hours', link: 'https://www.moma.org' },
        { name: 'Times Square', description: 'Iconic entertainment district', cost: 0, duration: '1-2 hours' },
        { name: 'Statue of Liberty', description: 'Historic monument and ferry ride', cost: 25, duration: '4 hours', link: 'https://www.nps.gov/stli' },
        { name: 'Wall Street & 9/11 Museum', description: 'Financial district and memorial', cost: 30, duration: '3 hours' },
        { name: 'Broadway Show', description: 'World-famous theater experience', cost: 150, duration: '2.5 hours' },
        { name: 'Brooklyn Bridge', description: 'Walk across historic bridge', cost: 0, duration: '1 hour' },
        { name: 'Shopping in SoHo', description: 'Trendy shopping district', cost: 50, duration: '2-3 hours' },
        { name: 'Empire State Building', description: 'Iconic skyscraper observation deck', cost: 45, duration: '1.5 hours', link: 'https://www.esbnyc.com' },
      ],
      restaurants: [
        { restaurant: 'Shake Shack', cuisine: 'American', estimatedCost: 15, location: 'Madison Square Park' },
        { restaurant: 'Carbone', cuisine: 'Italian', estimatedCost: 85, location: 'Greenwich Village' },
        { restaurant: 'Joe\'s Pizza', cuisine: 'Pizza', estimatedCost: 12, location: 'Multiple locations' },
        { restaurant: 'Peter Luger', cuisine: 'Steakhouse', estimatedCost: 120, location: 'Brooklyn' },
        { restaurant: 'Momofuku', cuisine: 'Asian Fusion', estimatedCost: 65, location: 'East Village' },
        { restaurant: 'Levain Bakery', cuisine: 'Bakery', estimatedCost: 10, location: 'Upper West Side' },
        { restaurant: 'Katz\'s Delicatessen', cuisine: 'Deli', estimatedCost: 25, location: 'Lower East Side' },
        { restaurant: 'Nobu', cuisine: 'Japanese', estimatedCost: 150, location: 'Tribeca' },
      ],
    },
    'Las Vegas': {
      activities: [
        { name: 'The Strip Walking Tour', description: 'Explore iconic casinos and hotels', cost: 0, duration: '2-3 hours' },
        { name: 'Bellagio Fountains', description: 'Free spectacular water show', cost: 0, duration: '30 minutes', link: 'https://bellagio.mgmresorts.com' },
        { name: 'High Roller Observation Wheel', description: 'World\'s tallest observation wheel', cost: 35, duration: '30 minutes', link: 'https://www.caesars.com/linq/high-roller' },
        { name: 'Fremont Street Experience', description: 'Historic downtown light show', cost: 0, duration: '2 hours' },
        { name: 'Red Rock Canyon', description: 'Stunning desert scenery drive', cost: 15, duration: '3-4 hours' },
        { name: 'Cirque du Soleil Show', description: 'World-class acrobatic performance', cost: 125, duration: '90 minutes' },
        { name: 'Neon Museum', description: 'Vintage Vegas sign collection', cost: 30, duration: '1.5 hours', link: 'https://www.neonmuseum.org' },
        { name: 'Casino Gaming', description: 'Try your luck at the tables', cost: 100, duration: '2-3 hours' },
        { name: 'Valley of Fire State Park', description: 'Ancient red rock formations', cost: 10, duration: '4 hours' },
        { name: 'Venetian Gondola Ride', description: 'Indoor canal gondola experience', cost: 35, duration: '15 minutes' },
        { name: 'Mob Museum', description: 'Interactive organized crime history', cost: 35, duration: '2 hours', link: 'https://themobmuseum.org' },
        { name: 'Hoover Dam Tour', description: 'Engineering marvel tour', cost: 45, duration: '4 hours' },
      ],
      restaurants: [
        { restaurant: 'Hash House A Go Go', cuisine: 'American', estimatedCost: 25, location: 'The LINQ' },
        { restaurant: 'Gordon Ramsay Hell\'s Kitchen', cuisine: 'Contemporary', estimatedCost: 95, location: 'Caesars Palace', link: 'https://www.caesars.com/caesars-palace/restaurants/hells-kitchen' },
        { restaurant: 'Peppermill Restaurant', cuisine: 'American Diner', estimatedCost: 22, location: 'Las Vegas Blvd' },
        { restaurant: 'Bacchanal Buffet', cuisine: 'Buffet', estimatedCost: 75, location: 'Caesars Palace' },
        { restaurant: 'Lotus of Siam', cuisine: 'Thai', estimatedCost: 45, location: 'East Sahara' },
        { restaurant: 'Mon Ami Gabi', cuisine: 'French Bistro', estimatedCost: 55, location: 'Paris Las Vegas' },
        { restaurant: 'In-N-Out Burger', cuisine: 'Fast Food', estimatedCost: 12, location: 'Multiple locations' },
        { restaurant: 'Joe\'s Seafood', cuisine: 'Seafood/Steak', estimatedCost: 85, location: 'The Forum Shops' },
        { restaurant: 'Eggslut', cuisine: 'Breakfast', estimatedCost: 18, location: 'The Cosmopolitan' },
        { restaurant: 'é by José Andrés', cuisine: 'Fine Dining', estimatedCost: 350, location: 'The Cosmopolitan' },
      ],
    },
    default: {
      activities: [
        { name: 'City Walking Tour', description: 'Discover the city on foot', cost: 25, duration: '3 hours' },
        { name: 'Local Museum Visit', description: 'Explore cultural heritage', cost: 20, duration: '2 hours' },
        { name: 'Historic District', description: 'Visit architectural landmarks', cost: 0, duration: '2 hours' },
        { name: 'Local Market', description: 'Browse local crafts and food', cost: 15, duration: '1.5 hours' },
        { name: 'Scenic Viewpoint', description: 'Panoramic city views', cost: 10, duration: '1 hour' },
        { name: 'Cultural Show', description: 'Evening entertainment', cost: 75, duration: '2 hours' },
      ],
      restaurants: [
        { restaurant: 'Local Bistro', cuisine: 'Local', estimatedCost: 30, location: 'City Center' },
        { restaurant: 'Fine Dining Restaurant', cuisine: 'International', estimatedCost: 85, location: 'Downtown' },
        { restaurant: 'Casual Café', cuisine: 'Café', estimatedCost: 15, location: 'Old Town' },
        { restaurant: 'Street Food Market', cuisine: 'Street Food', estimatedCost: 12, location: 'Market District' },
      ],
    },
  };

  const destinationKey = Object.keys(destinationData).find(
    key => key.toLowerCase() === tripData.destination.toLowerCase()
  ) || 'default';
  const data = destinationData[destinationKey];

  for (let i = 0; i < numDays; i++) {
    const currentDate = new Date(startDate);
    currentDate.setDate(startDate.getDate() + i);

    const morningActivity = data.activities[i * 3] || data.activities[0];
    const afternoonActivity = data.activities[i * 3 + 1] || data.activities[1];
    const eveningActivity = data.activities[i * 3 + 2] || data.activities[2];

    const breakfast = { ...data.restaurants[0], estimatedCost: 15 };
    const lunch = data.restaurants[(i * 2) % data.restaurants.length];
    const dinner = data.restaurants[(i * 2 + 1) % data.restaurants.length];

    const transportCost = tripData.transport === 'public transport' ? 15 : tripData.transport === 'taxi' ? 50 : 80;

    const dailyBudget =
      morningActivity.cost +
      afternoonActivity.cost +
      eveningActivity.cost +
      breakfast.estimatedCost +
      lunch.estimatedCost +
      dinner.estimatedCost +
      transportCost;

    days.push({
      day: i + 1,
      date: currentDate.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' }),
      morning: morningActivity,
      afternoon: afternoonActivity,
      evening: eveningActivity,
      meals: {
        breakfast,
        lunch,
        dinner,
      },
      transport: [
        { type: tripData.transport === 'public transport' ? 'Subway' : 'Taxi', from: 'Hotel', to: morningActivity.name, cost: transportCost / 3 },
        { type: tripData.transport === 'public transport' ? 'Subway' : 'Taxi', from: morningActivity.name, to: afternoonActivity.name, cost: transportCost / 3 },
        { type: tripData.transport === 'public transport' ? 'Subway' : 'Taxi', from: afternoonActivity.name, to: 'Hotel', cost: transportCost / 3 },
      ],
      dailyBudget,
    });
  }

  const accommodationPerNight = tripData.accommodation === 'hotel' ? 200 : tripData.accommodation === 'Airbnb' ? 120 : 50;
  const totalAccommodation = accommodationPerNight * (numDays - 1);
  const totalMeals = days.reduce((sum, day) => sum + day.meals.breakfast.estimatedCost + day.meals.lunch.estimatedCost + day.meals.dinner.estimatedCost, 0);
  const totalTransport = days.reduce((sum, day) => sum + day.transport.reduce((t, tr) => t + tr.cost, 0), 0);
  const totalActivities = days.reduce((sum, day) => sum + day.morning.cost + day.afternoon.cost + day.evening.cost, 0);
  const flightCost = 500 * tripData.travelers;
  const subtotal = totalAccommodation + totalMeals + totalTransport + totalActivities + flightCost;
  const contingency = subtotal * 0.15;

  return {
    tripData,
    days,
    totalBudget: {
      accommodation: totalAccommodation,
      meals: totalMeals,
      transport: totalTransport,
      activities: totalActivities,
      flights: flightCost,
      contingency,
      total: subtotal + contingency,
    },
  };
}