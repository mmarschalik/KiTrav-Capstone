import { ArrowLeft } from 'lucide-react';
import { GeneratedItinerary } from '../App';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { useState } from 'react';

interface BookingSummaryProps {
  itinerary: GeneratedItinerary;
  onBack: () => void;
}

interface BookingItem {
  id: string;
  type: 'flight' | 'hotel' | 'activity';
  name: string;
  details: string[];
  price: number;
  image?: string;
}

export function BookingSummary({ itinerary, onBack }: BookingSummaryProps) {
  const { tripData, days, totalBudget } = itinerary;

  const createBookingItems = (): BookingItem[] => {
    const items: BookingItem[] = [];

    // Add flight
    items.push({
      id: 'flight-1',
      type: 'flight',
      name: `Flight to ${tripData.destination}`,
      details: [
        `${tripData.startDate} • ${tripData.endDate}`,
        `Departure: 11:00 AM • Dest • Economy Class`
      ],
      price: totalBudget.flights / tripData.travelers,
    });

    // Add accommodation
    const nights = days.length - 1;
    items.push({
      id: 'hotel-1',
      type: 'hotel',
      name: `${tripData.accommodation === 'hotel' ? 'Hotel' : tripData.accommodation} in ${tripData.destination}`,
      details: [
        `Check-in: ${tripData.startDate} • Check-out: ${tripData.endDate} • ${tripData.travelers} Guest${tripData.travelers > 1 ? 's' : ''}`,
        `${nights} night${nights > 1 ? 's' : ''}`
      ],
      price: totalBudget.accommodation / tripData.travelers,
    });

    // Add top activities from the itinerary
    const uniqueActivities = new Map<string, { activity: any; count: number }>();

    days.forEach(day => {
      [day.morning, day.afternoon, day.evening].forEach(activity => {
        if (activity.cost > 0) {
          const existing = uniqueActivities.get(activity.name);
          if (existing) {
            existing.count += 1;
          } else {
            uniqueActivities.set(activity.name, { activity, count: 1 });
          }
        }
      });
    });

    // Convert to array and sort by total cost
    const activityList = Array.from(uniqueActivities.entries())
      .map(([name, data]) => ({
        name,
        ...data.activity,
        totalCost: data.activity.cost * data.count,
        count: data.count
      }))
      .sort((a, b) => b.totalCost - a.totalCost)
      .slice(0, 4);

    activityList.forEach((activity, index) => {
      items.push({
        id: `activity-${index}`,
        type: 'activity',
        name: activity.name,
        details: [
          activity.description,
          `${activity.count > 1 ? `${activity.count} visits • ` : ''}Includes admission`
        ],
        price: activity.cost,
      });
    });

    return items;
  };

  const [bookingItems, setBookingItems] = useState<BookingItem[]>(createBookingItems());

  const handleRemoveItem = (itemId: string) => {
    setBookingItems(items => items.filter(item => item.id !== itemId));
  };

  const calculateTotal = () => {
    const basePrice = bookingItems.reduce((sum, item) => sum + (item.price * tripData.travelers), 0);
    const taxes = basePrice * 0.12;
    const serviceFee = basePrice * 0.05;
    const total = basePrice + taxes + serviceFee;

    return {
      basePrice,
      taxes,
      serviceFee,
      total
    };
  };

  const totals = calculateTotal();

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-6 py-8">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-800 mb-6"
        >
          <ArrowLeft size={20} />
          Back
        </button>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Left side - Booking items */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-sm p-8">
              <h1 className="text-3xl mb-2">Your Booking Summary</h1>
              <p className="text-gray-600 mb-8">Below is the list of items in your cart.</p>

              <div className="space-y-6">
                {bookingItems.map((item) => (
                  <div key={item.id} className="flex gap-4 pb-6 border-b border-gray-200 last:border-b-0">
                    <div className="w-24 h-24 flex-shrink-0 bg-gray-100 rounded-lg overflow-hidden">
                      <ImageWithFallback
                        src={`https://source.unsplash.com/200x200/?${item.type === 'flight' ? 'airplane' : item.type === 'hotel' ? 'hotel,luxury' : item.name.toLowerCase()}`}
                        alt={item.name}
                        className="w-full h-full object-cover"
                      />
                    </div>

                    <div className="flex-1">
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="font-medium text-gray-900">{item.name}</h3>
                        <p className="font-medium text-gray-900 whitespace-nowrap ml-4">
                          {formatCurrency(item.price)} x {tripData.travelers}
                        </p>
                      </div>

                      {item.details.map((detail, idx) => (
                        <p key={idx} className="text-sm text-gray-600">
                          {detail}
                        </p>
                      ))}

                      <button
                        onClick={() => handleRemoveItem(item.id)}
                        className="text-sm text-red-500 hover:text-red-600 mt-2"
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right side - Summary panel */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-sm p-6 sticky top-8">
              <h2 className="text-xl mb-2">Booking Summary</h2>
              <p className="text-sm text-gray-600 mb-6">Below is a list of your items.</p>

              <div className="space-y-4 mb-6">
                <div className="text-sm text-blue-600 font-medium mb-3">Price Breakdown</div>

                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Base Price</span>
                  <span className="text-gray-900">{formatCurrency(totals.basePrice)}</span>
                </div>

                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Taxes</span>
                  <span className="text-gray-900">{formatCurrency(totals.taxes)}</span>
                </div>

                <div className="flex justify-between text-sm pb-4 border-b border-gray-200">
                  <span className="text-gray-600">Service Fee</span>
                  <span className="text-gray-900">{formatCurrency(totals.serviceFee)}</span>
                </div>

                <div className="flex justify-between items-center pt-2">
                  <span className="font-medium text-gray-900">Total</span>
                  <span className="text-2xl font-semibold text-gray-900">
                    {formatCurrency(totals.total)}
                  </span>
                </div>
              </div>

              <button className="w-full bg-blue-600 text-white py-3 rounded-lg hover:bg-blue-700 transition-colors font-medium">
                Continue to Book
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
