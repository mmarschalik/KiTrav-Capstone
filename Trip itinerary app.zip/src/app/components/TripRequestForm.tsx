import { useState } from 'react';
import { ArrowLeft, Users, Calendar as CalendarIcon, MapPin, DollarSign, Plane, Hotel, Utensils, Car } from 'lucide-react';
import { TripData } from '../App';

interface TripRequestFormProps {
  onBack: () => void;
  onSubmit: (tripData: TripData) => void;
  initialData?: Partial<TripData>;
}

export function TripRequestForm({ onBack, onSubmit, initialData }: TripRequestFormProps) {
  const [formData, setFormData] = useState<TripData>({
    destination: initialData?.destination || '',
    travelers: initialData?.travelers || 2,
    startDate: initialData?.startDate || '2026-05-01',
    endDate: initialData?.endDate || '2026-05-03',
    travelType: initialData?.travelType || ['leisure'],
    accommodation: initialData?.accommodation || 'hotel',
    dining: initialData?.dining || 'local',
    transport: initialData?.transport || 'public transport',
    budget: initialData?.budget || 1500,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const travelTypes = ['leisure', 'cultural', 'culinary', 'shopping', 'adventure', 'business'];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-6 py-8">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-blue-600 hover:text-blue-700 mb-6"
        >
          <ArrowLeft size={20} />
          Back to Search
        </button>

        <div className="bg-white rounded-2xl shadow-lg p-8">
          <h2 className="text-3xl mb-2 text-blue-600">Plan Your Trip</h2>
          <p className="text-gray-600 mb-8">Tell us about your travel plans and preferences</p>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                  <MapPin size={18} className="text-blue-600" />
                  Destination
                </label>
                <input
                  type="text"
                  value={formData.destination}
                  onChange={(e) => setFormData({ ...formData, destination: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="e.g., New York City"
                  required
                />
              </div>

              <div>
                <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                  <Users size={18} className="text-blue-600" />
                  Number of Travelers
                </label>
                <input
                  type="number"
                  min="1"
                  value={formData.travelers}
                  onChange={(e) => setFormData({ ...formData, travelers: parseInt(e.target.value) })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>

              <div>
                <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                  <CalendarIcon size={18} className="text-blue-600" />
                  Start Date
                </label>
                <input
                  type="date"
                  value={formData.startDate}
                  onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>

              <div>
                <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                  <CalendarIcon size={18} className="text-blue-600" />
                  End Date
                </label>
                <input
                  type="date"
                  value={formData.endDate}
                  onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>
            </div>

            <div>
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                <Plane size={18} className="text-blue-600" />
                Type of Travel (select all that apply)
              </label>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {travelTypes.map((type) => (
                  <label key={type} className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={formData.travelType.includes(type)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setFormData({ ...formData, travelType: [...formData.travelType, type] });
                        } else {
                          setFormData({ ...formData, travelType: formData.travelType.filter((t) => t !== type) });
                        }
                      }}
                      className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                    />
                    <span className="capitalize">{type}</span>
                  </label>
                ))}
              </div>
            </div>

            <div>
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                <Hotel size={18} className="text-blue-600" />
                Accommodation Preference
              </label>
              <select
                value={formData.accommodation}
                onChange={(e) => setFormData({ ...formData, accommodation: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="hotel">Hotel</option>
                <option value="Airbnb">Airbnb</option>
                <option value="hostel">Hostel</option>
              </select>
            </div>

            <div>
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                <Utensils size={18} className="text-blue-600" />
                Dining Preference
              </label>
              <select
                value={formData.dining}
                onChange={(e) => setFormData({ ...formData, dining: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="local">Local</option>
                <option value="gourmet">Gourmet</option>
                <option value="fast food">Fast Food</option>
                <option value="mixed">Mixed</option>
              </select>
            </div>

            <div>
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                <Car size={18} className="text-blue-600" />
                Transport Preference
              </label>
              <select
                value={formData.transport}
                onChange={(e) => setFormData({ ...formData, transport: e.target.value })}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="public transport">Public Transport</option>
                <option value="taxi">Taxi / Rideshare</option>
                <option value="rental car">Rental Car</option>
              </select>
            </div>

            <div>
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700 mb-2">
                <DollarSign size={18} className="text-blue-600" />
                Budget Range (Optional)
              </label>
              <input
                type="number"
                value={formData.budget || ''}
                onChange={(e) => setFormData({ ...formData, budget: e.target.value ? parseInt(e.target.value) : undefined })}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter your total budget"
              />
            </div>

            <button
              type="submit"
              className="w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white py-4 rounded-lg hover:from-blue-700 hover:to-blue-800 transition-all shadow-lg text-lg font-medium"
            >
              Generate My Itinerary
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
