import { ArrowLeft, Download, Calendar, Users, DollarSign, Plane, Hotel, Utensils, MapPin, ExternalLink } from 'lucide-react';
import { GeneratedItinerary } from '../App';
import logoImg from 'figma:asset/2b6b775675bf55c7fea2f340d906ba30b5036695.png';

interface TripItineraryProps {
  itinerary: GeneratedItinerary;
  onBack: () => void;
  onBookItinerary: () => void;
}

export function TripItinerary({ itinerary, onBack, onBookItinerary }: TripItineraryProps) {
  const { tripData, days, totalBudget } = itinerary;

  const handleExportPDF = () => {
    window.print();
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(amount);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="flex items-center justify-between mb-8 print:hidden">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-blue-600 hover:text-blue-700"
          >
            <ArrowLeft size={20} />
            Plan Another Trip
          </button>
          <div className="flex gap-3">
            <button
              onClick={handleExportPDF}
              className="flex items-center gap-2 px-6 py-3 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors shadow-sm"
            >
              <Download size={20} />
              Export as PDF
            </button>
            <button
              onClick={onBookItinerary}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors shadow-md font-medium"
            >
              Book Itinerary
            </button>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
          <div className="border-b border-gray-200 pb-6 mb-6">
            <img src={logoImg} alt="Kitravia" className="h-12 mb-6" />
            <h1 className="text-4xl mb-4">
              {tripData.destination} Trip Itinerary
            </h1>
            <div className="flex flex-wrap gap-6 text-gray-600">
              <div className="flex items-center gap-2">
                <Calendar size={20} className="text-blue-600" />
                <span>{tripData.startDate} to {tripData.endDate}</span>
              </div>
              <div className="flex items-center gap-2">
                <Users size={20} className="text-blue-600" />
                <span>{tripData.travelers} Traveler{tripData.travelers > 1 ? 's' : ''}</span>
              </div>
              <div className="flex items-center gap-2">
                <DollarSign size={20} className="text-blue-600" />
                <span>Total Budget: {formatCurrency(totalBudget.total)}</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="flex items-center gap-2 text-blue-600 mb-1">
                <Plane size={18} />
                <span className="text-sm">Flights</span>
              </div>
              <p className="text-2xl font-semibold">{formatCurrency(totalBudget.flights)}</p>
            </div>
            <div className="bg-purple-50 p-4 rounded-lg">
              <div className="flex items-center gap-2 text-purple-600 mb-1">
                <Hotel size={18} />
                <span className="text-sm">Accommodation</span>
              </div>
              <p className="text-2xl font-semibold">{formatCurrency(totalBudget.accommodation)}</p>
            </div>
            <div className="bg-green-50 p-4 rounded-lg">
              <div className="flex items-center gap-2 text-green-600 mb-1">
                <Utensils size={18} />
                <span className="text-sm">Meals</span>
              </div>
              <p className="text-2xl font-semibold">{formatCurrency(totalBudget.meals)}</p>
            </div>
            <div className="bg-orange-50 p-4 rounded-lg">
              <div className="flex items-center gap-2 text-orange-600 mb-1">
                <MapPin size={18} />
                <span className="text-sm">Activities</span>
              </div>
              <p className="text-2xl font-semibold">{formatCurrency(totalBudget.activities)}</p>
            </div>
            <div className="bg-yellow-50 p-4 rounded-lg">
              <div className="flex items-center gap-2 text-yellow-600 mb-1">
                <MapPin size={18} />
                <span className="text-sm">Transport</span>
              </div>
              <p className="text-2xl font-semibold">{formatCurrency(totalBudget.transport)}</p>
            </div>
            <div className="bg-gray-100 p-4 rounded-lg">
              <div className="flex items-center gap-2 text-gray-600 mb-1">
                <DollarSign size={18} />
                <span className="text-sm">Contingency</span>
              </div>
              <p className="text-2xl font-semibold">{formatCurrency(totalBudget.contingency)}</p>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          {days.map((day) => (
            <div key={day.day} className="bg-white rounded-xl shadow-lg overflow-hidden">
              <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-6 py-4">
                <h3 className="text-2xl">
                  Day {day.day} - {day.date}
                </h3>
                <p className="text-blue-100">Daily Budget: {formatCurrency(day.dailyBudget)}</p>
              </div>

              <div className="p-6">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-gray-200">
                        <th className="text-left py-3 px-4 text-gray-700">Time</th>
                        <th className="text-left py-3 px-4 text-gray-700">Activity</th>
                        <th className="text-left py-3 px-4 text-gray-700">Details</th>
                        <th className="text-right py-3 px-4 text-gray-700">Cost</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr className="border-b border-gray-100">
                        <td className="py-4 px-4 align-top">
                          <span className="inline-block bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm">
                            Morning
                          </span>
                        </td>
                        <td className="py-4 px-4 align-top">
                          <div className="font-medium text-gray-900">{day.morning.name}</div>
                          <div className="text-sm text-gray-500">{day.morning.duration}</div>
                        </td>
                        <td className="py-4 px-4 align-top">
                          <p className="text-gray-600">{day.morning.description}</p>
                          {day.morning.link && (
                            <a
                              href={day.morning.link}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-blue-600 hover:text-blue-700 text-sm flex items-center gap-1 mt-1"
                            >
                              Visit Website <ExternalLink size={14} />
                            </a>
                          )}
                        </td>
                        <td className="py-4 px-4 text-right align-top font-medium">
                          {formatCurrency(day.morning.cost)}
                        </td>
                      </tr>

                      <tr className="bg-green-50 border-b border-gray-100">
                        <td className="py-4 px-4 align-top">
                          <span className="inline-block bg-green-600 text-white px-3 py-1 rounded-full text-sm">
                            Lunch
                          </span>
                        </td>
                        <td className="py-4 px-4 align-top">
                          <div className="font-medium text-gray-900">{day.meals.lunch.restaurant}</div>
                          <div className="text-sm text-gray-500">{day.meals.lunch.cuisine}</div>
                        </td>
                        <td className="py-4 px-4 align-top">
                          <p className="text-gray-600">{day.meals.lunch.location}</p>
                        </td>
                        <td className="py-4 px-4 text-right align-top font-medium">
                          {formatCurrency(day.meals.lunch.estimatedCost)}
                        </td>
                      </tr>

                      <tr className="border-b border-gray-100">
                        <td className="py-4 px-4 align-top">
                          <span className="inline-block bg-orange-100 text-orange-700 px-3 py-1 rounded-full text-sm">
                            Afternoon
                          </span>
                        </td>
                        <td className="py-4 px-4 align-top">
                          <div className="font-medium text-gray-900">{day.afternoon.name}</div>
                          <div className="text-sm text-gray-500">{day.afternoon.duration}</div>
                        </td>
                        <td className="py-4 px-4 align-top">
                          <p className="text-gray-600">{day.afternoon.description}</p>
                          {day.afternoon.link && (
                            <a
                              href={day.afternoon.link}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-blue-600 hover:text-blue-700 text-sm flex items-center gap-1 mt-1"
                            >
                              Visit Website <ExternalLink size={14} />
                            </a>
                          )}
                        </td>
                        <td className="py-4 px-4 text-right align-top font-medium">
                          {formatCurrency(day.afternoon.cost)}
                        </td>
                      </tr>

                      <tr className="bg-green-50 border-b border-gray-100">
                        <td className="py-4 px-4 align-top">
                          <span className="inline-block bg-green-600 text-white px-3 py-1 rounded-full text-sm">
                            Dinner
                          </span>
                        </td>
                        <td className="py-4 px-4 align-top">
                          <div className="font-medium text-gray-900">{day.meals.dinner.restaurant}</div>
                          <div className="text-sm text-gray-500">{day.meals.dinner.cuisine}</div>
                        </td>
                        <td className="py-4 px-4 align-top">
                          <p className="text-gray-600">{day.meals.dinner.location}</p>
                        </td>
                        <td className="py-4 px-4 text-right align-top font-medium">
                          {formatCurrency(day.meals.dinner.estimatedCost)}
                        </td>
                      </tr>

                      <tr className="border-b border-gray-100">
                        <td className="py-4 px-4 align-top">
                          <span className="inline-block bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-sm">
                            Evening
                          </span>
                        </td>
                        <td className="py-4 px-4 align-top">
                          <div className="font-medium text-gray-900">{day.evening.name}</div>
                          <div className="text-sm text-gray-500">{day.evening.duration}</div>
                        </td>
                        <td className="py-4 px-4 align-top">
                          <p className="text-gray-600">{day.evening.description}</p>
                          {day.evening.link && (
                            <a
                              href={day.evening.link}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-blue-600 hover:text-blue-700 text-sm flex items-center gap-1 mt-1"
                            >
                              Visit Website <ExternalLink size={14} />
                            </a>
                          )}
                        </td>
                        <td className="py-4 px-4 text-right align-top font-medium">
                          {formatCurrency(day.evening.cost)}
                        </td>
                      </tr>

                      <tr className="bg-yellow-50">
                        <td className="py-4 px-4 align-top">
                          <span className="inline-block bg-yellow-600 text-white px-3 py-1 rounded-full text-sm">
                            Transport
                          </span>
                        </td>
                        <td className="py-4 px-4 align-top" colSpan={2}>
                          <div className="space-y-1">
                            {day.transport.map((t, idx) => (
                              <div key={idx} className="text-sm text-gray-700">
                                {t.type}: {t.from} → {t.to}
                              </div>
                            ))}
                          </div>
                        </td>
                        <td className="py-4 px-4 text-right align-top font-medium">
                          {formatCurrency(day.transport.reduce((sum, t) => sum + t.cost, 0))}
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-8 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-xl p-8 shadow-lg">
          <h3 className="text-2xl mb-4">Travel Tips for {tripData.destination}</h3>
          <ul className="space-y-2">
            <li className="flex items-start gap-2">
              <span className="text-blue-200">•</span>
              <span>Book attractions in advance to skip the lines and save time</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-blue-200">•</span>
              <span>Download offline maps before your trip for easy navigation</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-blue-200">•</span>
              <span>Consider a city pass for bundled attractions at a discounted rate</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-blue-200">•</span>
              <span>Keep a 15% contingency buffer for unexpected expenses and spontaneous activities</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}
