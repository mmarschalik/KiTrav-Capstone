import { useState } from 'react';
import { Send, Mic } from 'lucide-react';
import logoImg from 'figma:asset/2b6b775675bf55c7fea2f340d906ba30b5036695.png';
import { TripData } from '../App';
import { TripRequestForm } from './TripRequestForm';
import { parseSearchQuery } from '../utils/parseSearchQuery';

interface TripPlannerChatProps {
  onGenerateItinerary: (tripData: TripData) => void;
}

export function TripPlannerChat({ onGenerateItinerary }: TripPlannerChatProps) {
  const [showForm, setShowForm] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [parsedTripData, setParsedTripData] = useState<Partial<TripData>>({});

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      const parsed = parseSearchQuery(searchQuery);
      setParsedTripData(parsed);
      setShowForm(true);
    }
  };

  const quickActions = [
    {
      icon: '📝',
      label: 'Help me plan\na trip...',
      color: 'bg-white',
      data: {}
    },
    {
      icon: '📍',
      label: 'Suggest a new\nplace to visit',
      color: 'bg-white',
      data: {}
    },
    {
      icon: '💰',
      label: 'Plan a budget-\nfriendly getaway',
      color: 'bg-white',
      data: {
        budget: 1000,
        accommodation: 'hostel',
        dining: 'local'
      }
    },
    {
      icon: '🚗',
      label: 'Road trip to\nLos Angeles, 3\ndays, 2 friends',
      color: 'bg-white',
      data: {
        destination: 'Los Angeles',
        travelers: 2,
        startDate: '2026-05-01',
        endDate: '2026-05-03',
        transport: 'rental car',
        travelType: ['leisure']
      }
    },
  ];

  const handleQuickAction = (actionData: Partial<TripData>) => {
    setParsedTripData(actionData);
    setShowForm(true);
  };

  if (showForm) {
    return (
      <TripRequestForm
        onBack={() => setShowForm(false)}
        onSubmit={onGenerateItinerary}
        initialData={parsedTripData}
      />
    );
  }

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <div className="max-w-4xl mx-auto w-full px-6 py-12 flex-1 flex flex-col justify-center">
        <div className="text-center mb-12">
          

          <h1 className="text-5xl text-[#0048a8] text-center mx-[0px] mt-[0px] mb-[30px]">
            Plan Your Trip
          </h1>
        

          <p className="text-gray-700 mb-2 text-[24px]">
            Your personalized trip planner for smart travelers 🌍✈️
          </p>
          <p className="text-gray-600 max-w-3xl mx-auto leading-relaxed text-[24px] px-[0px] py-[10px]">Experience stress-free travel planning with Kitravia! Kitravia helps you plan incredible local and international trips ✈️🌍, tailored to your budget. Discover top destinations, cheap flights, accommodations, activities, tour packages, car rentals, and more! Travel like a pro ⭐</p>
        </div>

        <div className="flex flex-wrap justify-center gap-4 mb-8">
          {quickActions.map((action, index) => (
            <button
              key={index}
              onClick={() => handleQuickAction(action.data)}
              className="bg-white border border-gray-200 px-6 py-5 rounded-2xl hover:shadow-lg transition-all shadow-sm flex flex-col items-center gap-2 text-center min-w-[160px] hover:border-gray-300"
            >
              <span className="text-3xl">{action.icon}</span>
              <span className="text-sm text-gray-700 whitespace-pre-line leading-snug">
                {action.label}
              </span>
            </button>
          ))}
        </div>

        <form onSubmit={handleSearchSubmit} className="mb-8">
          <div className="bg-white border-2 border-blue-400 rounded-2xl shadow-lg overflow-hidden">
            <textarea
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Where should Kitravia take you today?"
              className="w-full px-6 py-5 text-lg border-none outline-none resize-none min-h-[60px]"
              rows={1}
              onInput={(e) => {
                const target = e.target as HTMLTextAreaElement;
                target.style.height = 'auto';
                target.style.height = target.scrollHeight + 'px';
              }}
            />
            <div className="flex items-center justify-end gap-2 px-3 pb-3">
              <button
                type="button"
                className="flex items-center gap-2 px-4 py-2 text-gray-600 hover:text-gray-800 transition-colors rounded-lg hover:bg-gray-100"
              >
                <Mic size={20} className="text-red-500" />
                <span className="text-sm">Voice Mode</span>
              </button>
              <button
                type="submit"
                className="p-3 bg-gradient-to-r from-red-400 to-red-500 text-white rounded-full hover:from-red-500 hover:to-red-600 transition-all shadow-md"
              >
                <Send size={20} />
              </button>
            </div>
          </div>
          <p className="text-center text-xs text-gray-500 mt-3">
            KiTravia can make mistakes. Double check important information before completing booking transaction.
          </p>
        </form>
      </div>
    </div>
  );
}
