
  # Trip itinerary app

  This is a code bundle for Trip itinerary app. The original project is available at https://www.figma.com/design/f8SEns37raZx9zsxQcyTjh/Trip-itinerary-app.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  