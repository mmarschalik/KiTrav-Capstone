import { useState } from 'react';
import { useNavigate } from 'react-router';
import { Plane, Hotel, Ship, Car, MapPin, Compass, Palmtree, Tag, Mic, ArrowRight } from 'lucide-react';
import { Header } from '../components/Header';

export function Home() {
  const [query, setQuery] = useState('');
  const navigate = useNavigate();

  const handleSearch = () => {
    if (query.trim()) {
      navigate(`/search?q=${encodeURIComponent(query)}`);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  const quickActions = [
    { icon: Plane, label: 'Flight Booking', color: 'bg-blue-500' },
    { icon: Hotel, label: 'Hotel', color: 'bg-blue-500' },
    { icon: Ship, label: 'Cruise', color: 'bg-blue-500' },
    { icon: Car, label: 'Car Rental', color: 'bg-blue-500' },
    { icon: MapPin, label: 'Things to Do', color: 'bg-blue-500' },
    { icon: Compass, label: 'Places to Go', color: 'bg-blue-500' },
    { icon: Palmtree, label: 'Holiday Packages', color: 'bg-blue-500' },
    { icon: Tag, label: 'Vacation', color: 'bg-blue-500' },
    { icon: Tag, label: 'Hotel Deals', color: 'bg-blue-500' },
  ];

  return (
    <div className="min-h-screen bg-white">
      <Header />
      <div className="flex items-center justify-center p-8">
        <div className="max-w-4xl w-full">
        <div className="text-center mb-8">
          <h1 className="text-5xl mb-2">Like ChatGPT.</h1>
          <h1 className="text-5xl mb-8">But for your Travel needs.</h1>

          <p className="text-xl text-gray-700 mb-2">
            Hi, I'm Kitravia. I will be your AI travel agent.
          </p>

          <p className="text-gray-600 max-w-2xl mx-auto mb-8">
            Not sure where to start? Tell me where you want to go? What's your budget? Is there something
            specific you'd like to do? Do you need a rental car? We'll guide you through the booking process!
          </p>
        </div>

        <div className="mb-8">
          <div className="relative border-2 border-blue-400 rounded-2xl p-6 bg-white">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Where should Kitravia take you today?"
              className="w-full text-gray-700 text-lg outline-none pr-16"
            />

            <div className="flex items-center gap-4 mt-4">
              <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-full text-sm text-gray-700 hover:bg-gray-50">
                <Mic className="w-4 h-4 text-red-500" />
                Voice Mode
              </button>

              <button
                onClick={handleSearch}
                className="ml-auto w-10 h-10 bg-red-500 rounded-full flex items-center justify-center hover:bg-red-600 transition-colors"
              >
                <ArrowRight className="w-5 h-5 text-white" />
              </button>
            </div>
          </div>

          <p className="text-center text-gray-500 text-sm mt-3">Kitravia can make mistakes. Double check important information before completing booking transaction.</p>
        </div>

        <div className="flex flex-wrap justify-center gap-3">
          {quickActions.slice(0, 4).map((action, index) => (
            <button
              key={index}
              className={`${action.color} text-white px-6 py-3 rounded-lg flex items-center gap-2 hover:opacity-90 transition-opacity`}
            >
              <action.icon className="w-5 h-5" />
              {action.label}
              <ArrowRight className="w-4 h-4 ml-1" />
            </button>
          ))}
        </div>

        <div className="flex flex-wrap justify-center gap-3 mt-3">
          {quickActions.slice(4, 7).map((action, index) => (
            <button
              key={index}
              className={`${action.color} text-white px-6 py-3 rounded-lg flex items-center gap-2 hover:opacity-90 transition-opacity`}
            >
              <action.icon className="w-5 h-5" />
              {action.label}
              <ArrowRight className="w-4 h-4 ml-1" />
            </button>
          ))}
        </div>

        <div className="flex flex-wrap justify-center gap-3 mt-3">
          {quickActions.slice(7).map((action, index) => (
            <button
              key={index}
              className={`${action.color} text-white px-6 py-3 rounded-lg flex items-center gap-2 hover:opacity-90 transition-opacity`}
            >
              <action.icon className="w-5 h-5" />
              {action.label}
              <ArrowRight className="w-4 h-4 ml-1" />
            </button>
          ))}
        </div>
      </div>
      </div>
    </div>
  );
}
