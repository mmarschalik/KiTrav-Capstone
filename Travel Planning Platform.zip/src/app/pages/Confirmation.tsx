import { useLocation, useNavigate } from 'react-router';
import { CheckCircle, Calendar, MapPin, Plane, Hotel, User, Mail } from 'lucide-react';
import { Header } from '../components/Header';
import logo from '../../imports/image-0.png';

interface BookingItem {
  id: string;
  name: string;
  details: string;
  price: number;
  quantity: number;
  type: string;
  extraInfo?: string;
}

export function Confirmation() {
  const location = useLocation();
  const navigate = useNavigate();
  const bookingData = location.state || {};
  const { items = [], customerInfo = {}, total: passedTotal } = bookingData;

  // Calculate breakdown from items
  const basePrice = items.reduce((sum: number, item: BookingItem) => sum + (item.price * item.quantity), 0);
  const taxes = basePrice * 0.08;
  const serviceFee = 40.00;
  const total = passedTotal || (basePrice + taxes + serviceFee);

  const bookingNumber = 'KT' + Math.random().toString(36).substr(2, 9).toUpperCase();

  console.log('Confirmation items:', items);
  console.log('Base price:', basePrice);
  console.log('Total:', total);

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="max-w-4xl mx-auto p-6 py-12">

        {/* Success Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-green-100 rounded-full mb-4">
            <CheckCircle className="w-12 h-12 text-green-600" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Thank You for Your Booking!</h1>
          <p className="text-gray-600">Your trip has been confirmed. We've sent a confirmation email with all the details.</p>
        </div>

        {/* Booking Reference */}
        <div className="bg-blue-50 border-2 border-blue-200 rounded-lg p-6 mb-8">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-blue-600 font-medium mb-1">Booking Reference</p>
              <p className="text-2xl font-bold text-blue-900">{bookingNumber}</p>
            </div>
            <div className="text-right">
              <p className="text-sm text-blue-600 font-medium mb-1">Total Paid</p>
              <p className="text-2xl font-bold text-blue-900">${(total || 0).toFixed(2)}</p>
            </div>
          </div>
        </div>

        {/* Booking Summary */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
          <h2 className="text-xl font-semibold mb-6">Booking Summary</h2>

          <div className="space-y-6 mb-6">
            {items.map((item: BookingItem) => (
              <div key={item.id} className="flex gap-4 pb-6 border-b border-gray-200 last:border-0">
                <div className="flex-shrink-0 w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  {item.type === 'flight' && <Plane className="w-6 h-6 text-blue-600" />}
                  {item.type === 'hotel' && <Hotel className="w-6 h-6 text-blue-600" />}
                  {(item.type === 'landmark' || item.type === 'event') && <MapPin className="w-6 h-6 text-blue-600" />}
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900 mb-1">{item.name}</h3>
                  <p className="text-sm text-gray-600 mb-1">{item.details}</p>
                  {item.extraInfo && (
                    <p className="text-xs text-gray-500">{item.extraInfo}</p>
                  )}
                </div>
                <div className="text-right">
                  <p className="font-semibold text-gray-900">${item.price.toFixed(2)} × {item.quantity}</p>
                  <p className="text-sm text-gray-500">${(item.price * item.quantity).toFixed(2)}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Price Breakdown */}
          <div className="border-t border-gray-200 pt-6 space-y-3">
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Subtotal</span>
              <span className="font-medium text-gray-900">${(basePrice || 0).toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Taxes (8%)</span>
              <span className="font-medium text-gray-900">${(taxes || 0).toFixed(2)}</span>
            </div>
            <div className="flex justify-between text-sm pb-3 border-b border-gray-200">
              <span className="text-gray-600">Service Fee</span>
              <span className="font-medium text-gray-900">${serviceFee.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center pt-2">
              <span className="text-lg font-semibold text-gray-900">Total Paid</span>
              <span className="text-2xl font-bold text-blue-600">${(total || 0).toFixed(2)}</span>
            </div>
          </div>
        </div>

        {/* Trip Details */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
          <h2 className="text-xl font-semibold mb-6">Trip Details</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="flex gap-3">
              <Calendar className="w-5 h-5 text-gray-400 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-gray-900">Travel Dates</p>
                <p className="text-sm text-gray-600">April 11-13, 2026</p>
              </div>
            </div>
            <div className="flex gap-3">
              <MapPin className="w-5 h-5 text-gray-400 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-gray-900">Destination</p>
                <p className="text-sm text-gray-600">Las Vegas, Nevada</p>
              </div>
            </div>
            <div className="flex gap-3">
              <User className="w-5 h-5 text-gray-400 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-gray-900">Travelers</p>
                <p className="text-sm text-gray-600">2 Adults</p>
              </div>
            </div>
            <div className="flex gap-3">
              <Mail className="w-5 h-5 text-gray-400 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-gray-900">Confirmation Sent To</p>
                <p className="text-sm text-gray-600">{customerInfo.email || 'your@email.com'}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Next Steps */}
        <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg p-6 mb-8">
          <h3 className="font-semibold text-gray-900 mb-4">What's Next?</h3>
          <ul className="space-y-3">
            <li className="flex gap-3">
              <span className="flex-shrink-0 w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-semibold">1</span>
              <p className="text-sm text-gray-700">Check your email for detailed booking confirmations and e-tickets</p>
            </li>
            <li className="flex gap-3">
              <span className="flex-shrink-0 w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-semibold">2</span>
              <p className="text-sm text-gray-700">Complete online check-in 24 hours before your flight</p>
            </li>
            <li className="flex gap-3">
              <span className="flex-shrink-0 w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-semibold">3</span>
              <p className="text-sm text-gray-700">Download the KiTravia app to manage your trip on the go</p>
            </li>
          </ul>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-4">
          <button
            onClick={() => navigate('/')}
            className="flex-1 px-6 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors"
          >
            Plan Another Trip
          </button>
          <button
            onClick={() => window.print()}
            className="flex-1 px-6 py-3 border-2 border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50 transition-colors"
          >
            Print Confirmation
          </button>
        </div>
      </div>
    </div>
  );
}
