import { useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router';
import { Menu, Mic, ArrowRight } from 'lucide-react';
import { FlightCard } from '../components/FlightCard';
import { ActivityCard } from '../components/ActivityCard';
import { Sidebar } from '../components/Sidebar';
import { Header } from '../components/Header';
import hotelImg1 from '../../imports/image-0.png';
import hotelImg2 from '../../imports/image-1.png';
import hotelImg3 from '../../imports/image-2.png';

export function SearchResults() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const initialQuery = searchParams.get('q') || '';
  const [query, setQuery] = useState('');
  const [selectedFlight, setSelectedFlight] = useState<number | null>(null);
  const [selectedHotel, setSelectedHotel] = useState<number | null>(null);
  const [selectedLandmarks, setSelectedLandmarks] = useState<number[]>([]);
  const [selectedEvents, setSelectedEvents] = useState<number[]>([]);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleSearch = () => {
    if (query.trim()) {
      // Handle additional queries
      console.log('New query:', query);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  const handleBooking = () => {
    const items = [];

    if (selectedFlight !== null) {
      const flight = flights[selectedFlight];
      items.push({
        id: `flight-${selectedFlight}`,
        name: `${flight.airline} - ${flight.flightNumber}`,
        image: hotelImg1,
        details: `${flight.route} • ${flight.duration}`,
        price: flight.price,
        quantity: 2,
        type: 'flight',
        extraInfo: `Departure: ${flight.departureTime} • ${flight.stops} • Economy Class`,
      });
    }

    if (selectedHotel !== null) {
      const hotel = hotels[selectedHotel];
      items.push({
        id: `hotel-${selectedHotel}`,
        name: hotel.name,
        image: hotel.image,
        details: `★ ${hotel.rating} • 2 nights`,
        price: hotel.pricePerNight,
        quantity: 2,
        type: 'hotel',
        extraInfo: 'Check-in: Apr 11, 2026 • Check-out: Apr 13, 2026 • 2 Guests',
      });
    }

    // Add selected landmarks
    selectedLandmarks.forEach(index => {
      const landmark = landmarks[index];
      items.push({
        id: `landmark-${index}`,
        name: landmark.name,
        image: landmark.image,
        details: landmark.location,
        price: 20,
        quantity: 2,
        type: 'landmark',
        extraInfo: 'Guided tour • 2-3 hours • Includes admission',
      });
    });

    // Add selected events
    selectedEvents.forEach(index => {
      const event = events[index];
      items.push({
        id: `event-${index}`,
        name: event.name,
        image: event.image,
        details: `${event.venue} • ${event.date}`,
        price: 97,
        quantity: 2,
        type: 'event',
        extraInfo: 'General Admission • 2 Tickets • All ages welcome',
      });
    });

    navigate('/checkout', { state: { items } });
  };

  const flights = [
    {
      airline: 'Delta Airlines',
      flightNumber: 'DL 2150',
      price: 325,
      departureTime: '2:10 PM',
      arrivalTime: '',
      duration: '1h 25m',
      stops: 'Direct',
      route: 'PHX → LAS',
    },
    {
      airline: 'Southwest',
      flightNumber: 'WN 2421',
      price: 199,
      departureTime: '8:45 PM',
      arrivalTime: '',
      duration: '1h 10m',
      stops: 'Direct',
      route: 'PHX → LAS',
    },
    {
      airline: 'American Airlines',
      flightNumber: 'AA 1534',
      price: 215,
      departureTime: '6:30 AM',
      arrivalTime: '',
      duration: '1h 15m',
      stops: 'Direct',
      route: 'PHX → LAS',
    },
    {
      airline: 'United Airlines',
      flightNumber: 'UA 892',
      price: 289,
      departureTime: '11:20 AM',
      arrivalTime: '',
      duration: '1h 20m',
      stops: 'Direct',
      route: 'PHX → LAS',
    },
    {
      airline: 'Frontier Airlines',
      flightNumber: 'F9 1056',
      price: 169,
      departureTime: '3:45 PM',
      arrivalTime: '',
      duration: '1h 12m',
      stops: 'Direct',
      route: 'PHX → LAS',
    },
    {
      airline: 'Spirit Airlines',
      flightNumber: 'NK 647',
      price: 159,
      departureTime: '5:15 PM',
      arrivalTime: '',
      duration: '1h 18m',
      stops: 'Direct',
      route: 'PHX → LAS',
    },
    {
      airline: 'Southwest',
      flightNumber: 'WN 3182',
      price: 209,
      departureTime: '10:00 AM',
      arrivalTime: '',
      duration: '1h 08m',
      stops: 'Direct',
      route: 'PHX → LAS',
    },
    {
      airline: 'Delta Airlines',
      flightNumber: 'DL 3891',
      price: 279,
      departureTime: '4:25 PM',
      arrivalTime: '',
      duration: '1h 22m',
      stops: 'Direct',
      route: 'PHX → LAS',
    },
  ];

  const hotels = [
    { name: 'Bellagio Hotel & Casino', rating: 4.8, pricePerNight: 289, image: 'https://images.unsplash.com/photo-1768836050428-06f17e0bd6e8?w=400&h=300&fit=crop' },
    { name: 'The Venetian Resort', rating: 4.7, pricePerNight: 329, image: 'https://www.sands.com/content/uploads/2021/07/the-venetian-las-vegas-the-first-integrated-resort.jpg' },
    { name: 'Wynn Las Vegas', rating: 4.9, pricePerNight: 399, image: 'https://travelnevada.com/wp-content/uploads/2014/04/WE_Desktop.jpg' },
    { name: 'MGM Grand', rating: 4.6, pricePerNight: 219, image: 'https://www.fivestaralliance.com/files/fivestaralliance.com/field/image/nodes/2010/13926/13926_0_mgmgrandhotelandcasino_fsa-g.jpg' },
    { name: 'Caesars Palace', rating: 4.7, pricePerNight: 349, image: 'https://dynamic-media-cdn.tripadvisor.com/media/photo-o/31/c1/38/96/caesars-palace-a-caesars.jpg?w=1400&h=-1&s=1' },
  ];

  const landmarks = [
    { name: 'Hoover Dam', location: 'Boulder City, Nevada', image: hotelImg1 },
    { name: 'Las Vegas Sign', location: 'Las Vegas Strip', image: hotelImg2 },
    { name: 'Fremont Street', location: 'Downtown Las Vegas', image: hotelImg3 },
    { name: 'Red Rock Canyon', location: 'Clark County, Nevada', image: hotelImg1 },
    { name: 'Old Las Vegas', location: 'Las Vegas Boulevard', image: hotelImg2 },
    { name: 'The Strip', location: 'Las Vegas, Nevada', image: 'https://images.unsplash.com/photo-1609142191215-47d38886eb4b?w=400&h=300&fit=crop' },
  ];

  const events = [
    { name: 'Music Festival', venue: 'Madison Square, Caesars', date: 'Apr 15, 2026', image: hotelImg1 },
    { name: 'Grand Canal Shoppes (Strip)', venue: 'The Venetian', date: 'Apr 16, 2026', image: hotelImg2 },
    { name: 'Machine Turning', venue: 'Treasure Island', date: 'Apr 17, 2026', image: hotelImg3 },
    { name: 'Blue Man Theatre (The Luxor)', venue: 'Luxor Hotel', date: 'Apr 18, 2026', image: hotelImg1 },
    { name: 'Christmas Lights', venue: 'Fremont Street', date: 'Dec 25, 2026', image: hotelImg2 },
    { name: 'Magic Show', venue: 'Entertainment, Caesars', date: 'Apr 20, 2026', image: hotelImg3 },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="flex">
        <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />

        {/* Main Content */}
        <div
          className={`flex-1 transition-all duration-300 ease-in-out ${
            sidebarOpen ? 'ml-64' : 'ml-0'
          }`}
        >
          {/* Sub Header */}
          <div className="bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="w-10 h-10 bg-blue-600 rounded flex items-center justify-center hover:bg-blue-700"
            >
              <Menu className="w-6 h-6 text-white" />
            </button>
          </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Chat History */}
        <div className="mb-8">
          <div className="bg-gray-200 rounded-2xl p-4 max-w-3xl mb-4 ml-auto">
            <p className="text-gray-800">
              {initialQuery || "I live in Phoenix I want to spend the upcoming weekend in Las Vegas with my friend and go party but also see special historic landmarks, we want to fly and stay at a 4 star casino."}
            </p>
          </div>

          <div className="mb-4">
            <p className="text-gray-600 mb-2">Researching your destination...</p>
            <p className="text-gray-700">
              Here is your trip information to destination Las Vegas, select the options you want.
              Let me know if you want to refine your search.
            </p>
          </div>

          {/* Input */}
          <div className="relative border-2 border-gray-300 rounded-2xl p-4 bg-white max-w-4xl">
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Describe additional details about your trip"
              className="w-full text-gray-700 outline-none pr-16"
            />

            <div className="flex items-center gap-4 mt-3">
              <button className="flex items-center gap-2 px-4 py-2 border border-gray-300 rounded-full text-sm text-gray-700 hover:bg-gray-50">
                <Mic className="w-4 h-4 text-red-500" />
                Voice Mode
              </button>

              <button
                onClick={handleSearch}
                className="ml-auto w-10 h-10 bg-red-500 rounded-full flex items-center justify-center hover:bg-red-600 transition-colors"
              >
                <ArrowRight className="w-5 h-5 text-white" />
              </button>
            </div>
          </div>
        </div>

        {/* Flights Section */}
        <section className="mb-12">
          <h2 className="text-2xl mb-4">Flights</h2>
          <div className="flex gap-4 overflow-x-auto pb-4">
            {flights.map((flight, index) => (
              <FlightCard
                key={index}
                {...flight}
                isSelected={selectedFlight === index}
                onSelect={() => setSelectedFlight(selectedFlight === index ? null : index)}
              />
            ))}
          </div>
        </section>

        {/* Hotels Section */}
        <section className="mb-12">
          <h2 className="text-2xl mb-4">Hotels</h2>
          <div className="flex gap-4 overflow-x-auto pb-4">
            {hotels.map((hotel, index) => (
              <ActivityCard
                key={index}
                title={hotel.name}
                subtitle={`★ ${hotel.rating}`}
                price={hotel.pricePerNight}
                priceLabel="night"
                image={hotel.image}
                type="hotel"
                isSelected={selectedHotel === index}
                onSelect={() => setSelectedHotel(selectedHotel === index ? null : index)}
              />
            ))}
          </div>
        </section>

        {/* Landmarks Section */}
        <section className="mb-12">
          <h2 className="text-2xl mb-4">Landmarks</h2>
          <div className="flex gap-4 overflow-x-auto pb-4">
            {landmarks.map((landmark, index) => (
              <ActivityCard
                key={index}
                title={landmark.name}
                subtitle={landmark.location}
                image={landmark.image}
                type="landmark"
                isSelected={selectedLandmarks.includes(index)}
                onSelect={() => {
                  if (selectedLandmarks.includes(index)) {
                    setSelectedLandmarks(selectedLandmarks.filter(i => i !== index));
                  } else {
                    setSelectedLandmarks([...selectedLandmarks, index]);
                  }
                }}
              />
            ))}
          </div>
        </section>

        {/* Events Section */}
        <section className="mb-12">
          <h2 className="text-2xl mb-4">Events</h2>
          <div className="flex gap-4 overflow-x-auto pb-4">
            {events.map((event, index) => (
              <ActivityCard
                key={index}
                title={event.name}
                subtitle={event.venue}
                date={event.date}
                image={event.image}
                type="event"
                isSelected={selectedEvents.includes(index)}
                onSelect={() => {
                  if (selectedEvents.includes(index)) {
                    setSelectedEvents(selectedEvents.filter(i => i !== index));
                  } else {
                    setSelectedEvents([...selectedEvents, index]);
                  }
                }}
              />
            ))}
          </div>
        </section>

        {/* Book Button */}
        <div className="fixed bottom-8 right-8">
          <button
            onClick={handleBooking}
            className="bg-blue-600 text-white px-8 py-3 rounded-lg text-lg font-medium hover:bg-blue-700 shadow-lg"
          >
            Book
          </button>
        </div>
      </div>
        </div>
      </div>
    </div>
  );
}
