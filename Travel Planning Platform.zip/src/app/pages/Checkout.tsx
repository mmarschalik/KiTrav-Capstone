import { useState } from 'react';
import { useLocation, useNavigate } from 'react-router';
import { ArrowLeft, Trash2 } from 'lucide-react';
import { PaymentModal } from '../components/PaymentModal';
import { Header } from '../components/Header';

interface CartItem {
  id: string;
  name: string;
  image: string;
  details: string;
  price: number;
  quantity: number;
  type: 'hotel' | 'flight' | 'activity' | 'landmark' | 'event';
  extraInfo?: string;
}

export function Checkout() {
  const location = useLocation();
  const navigate = useNavigate();
  const initialItems = location.state?.items || [];

  const [cartItems, setCartItems] = useState<CartItem[]>(initialItems);
  const [showPaymentModal, setShowPaymentModal] = useState(false);

  const handleRemoveItem = (id: string) => {
    setCartItems(cartItems.filter(item => item.id !== id));
  };

  const basePrice = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const taxes = basePrice * 0.08;
  const serviceFee = 40.00;
  const total = basePrice + taxes + serviceFee;

  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      <PaymentModal
        isOpen={showPaymentModal}
        onClose={() => setShowPaymentModal(false)}
        total={total}
        items={cartItems}
      />
      <div className="max-w-7xl mx-auto p-6">
        {/* Back Button */}
        <button
          onClick={() => navigate(-1)}
          className="mb-6 flex items-center gap-2 text-gray-700 hover:text-gray-900"
        >
          <ArrowLeft className="w-5 h-5" />
          <span>Back</span>
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Your Booking Summary */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg p-6 shadow-sm">
              <h2 className="text-xl font-semibold mb-2">Your Booking Summary</h2>
              <p className="text-sm text-gray-600 mb-6">Below is the list of items in your cart.</p>

              <div className="space-y-4">
                {cartItems.map((item) => (
                  <div key={item.id} className="border-b border-gray-200 pb-4 last:border-0">
                    <div className="flex gap-4">
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-16 h-16 rounded object-cover"
                      />
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <h3 className="font-semibold text-gray-900">{item.name}</h3>
                            <p className="text-xs text-gray-500">{item.details}</p>
                          </div>
                          <p className="font-semibold text-gray-900">
                            ${item.price.toFixed(2)} x {item.quantity}
                          </p>
                        </div>
                        {item.extraInfo && (
                          <p className="text-xs text-gray-600 mb-2">
                            {item.extraInfo}
                          </p>
                        )}
                        <button
                          onClick={() => handleRemoveItem(item.id)}
                          className="flex items-center gap-1 text-red-500 text-sm hover:text-red-700"
                        >
                          <Trash2 className="w-4 h-4" />
                          Remove
                        </button>
                      </div>
                    </div>
                  </div>
                ))}

                {cartItems.length === 0 && (
                  <div className="text-center py-12 text-gray-500">
                    <p>Your cart is empty</p>
                    <button
                      onClick={() => navigate('/search')}
                      className="mt-4 text-blue-600 hover:text-blue-700 font-medium"
                    >
                      Continue Shopping
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Booking Summary Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg p-6 shadow-sm sticky top-6">
              <h2 className="text-xl font-semibold mb-2">Booking Summary</h2>
              <p className="text-sm text-gray-600 mb-6">Below is a list of your items.</p>

              <div className="space-y-3 mb-6">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Price Breakdown</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Base Price</span>
                  <span className="font-medium">${basePrice.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Taxes</span>
                  <span className="font-medium">${taxes.toFixed(2)}</span>
                </div>
                <div className="flex justify-between pb-3 border-b border-gray-200">
                  <span className="text-gray-600">Service Fee</span>
                  <span className="font-medium">${serviceFee.toFixed(2)}</span>
                </div>
                <div className="flex justify-between items-center pt-3">
                  <div className="flex items-center gap-1">
                    <span className="font-semibold text-lg">Total</span>
                    <svg className="w-4 h-4 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <span className="text-2xl font-bold">${total.toFixed(2)}</span>
                </div>
              </div>

              <button
                onClick={() => setShowPaymentModal(true)}
                disabled={cartItems.length === 0}
                className="w-full bg-blue-600 text-white py-3 rounded-lg font-medium hover:bg-blue-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
              >
                Continue to Book
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
