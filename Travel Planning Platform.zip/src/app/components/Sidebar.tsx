import { X, Plus, Search } from 'lucide-react';
import { useNavigate } from 'react-router';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

export function Sidebar({ isOpen, onClose }: SidebarProps) {
  const navigate = useNavigate();

  const pastTrips = [
    'Las Vegas weekend',
    'Business trip to Vancouver',
    'Cultural trip to Nairobi',
  ];

  const handleNewTrip = () => {
    navigate('/');
    onClose();
  };

  return (
    <>
      {/* Sidebar */}
      <div
        className={`fixed top-0 left-0 h-full w-64 bg-blue-600 text-white z-50 transform transition-transform duration-300 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="p-4 flex items-center justify-between border-b border-white border-opacity-20">
            <button
              onClick={onClose}
              className="w-10 h-10 flex items-center justify-center hover:bg-white hover:bg-opacity-10 rounded transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
            <button className="w-10 h-10 flex items-center justify-center hover:bg-white hover:bg-opacity-10 rounded transition-colors">
              <Search className="w-6 h-6" />
            </button>
          </div>

          {/* New Trip Button */}
          <div className="p-4 border-b border-white border-opacity-20">
            <button
              onClick={handleNewTrip}
              className="w-full px-6 py-3 border-2 border-white rounded-full flex items-center justify-center gap-2 hover:bg-white hover:bg-opacity-10 transition-colors"
            >
              <Plus className="w-5 h-5" />
              <span className="font-medium">New Trip</span>
            </button>
          </div>

          {/* My Trips */}
          <div className="flex-1 p-4 overflow-y-auto">
            <h3 className="font-semibold mb-4">My Trips</h3>
            <div className="space-y-3">
              {pastTrips.map((trip, index) => (
                <button
                  key={index}
                  className="w-full text-left px-4 py-3 rounded-lg hover:bg-white hover:bg-opacity-10 transition-colors"
                >
                  {trip}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
