import { useState } from 'react';
import { InfoPopup } from './InfoPopup';

interface ActivityCardProps {
  title: string;
  subtitle: string;
  price?: number;
  priceLabel?: string;
  date?: string;
  image: string;
  type: 'hotel' | 'landmark' | 'event';
  isSelected?: boolean;
  onSelect?: () => void;
}

export function ActivityCard({
  title,
  subtitle,
  price,
  priceLabel = 'night',
  date,
  image,
  type,
  isSelected = false,
  onSelect,
}: ActivityCardProps) {
  const [showPopup, setShowPopup] = useState(false);
  const [popupPosition, setPopupPosition] = useState({ x: 0, y: 0 });

  const handleLearnMore = (e: React.MouseEvent<HTMLButtonElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setPopupPosition({
      x: rect.left + rect.width / 2,
      y: rect.top,
    });
    setShowPopup(true);
  };

  const getMoreInfo = () => {
    const baseInfo: Record<string, string> = {
      'Name': title,
      'Location': subtitle,
    };

    if (type === 'hotel') {
      return {
        ...baseInfo,
        'Price': price ? `$${price}/${priceLabel}` : 'N/A',
        'Amenities': 'Pool, Spa, Fitness Center, Restaurant',
        'Check-in': '3:00 PM',
        'Check-out': '11:00 AM',
        'Cancellation': 'Free cancellation up to 24 hours before',
      };
    } else if (type === 'event') {
      return {
        ...baseInfo,
        'Date': date || 'TBA',
        'Duration': '2-3 hours',
        'Tickets': 'Available online',
        'Age Restriction': '18+',
      };
    } else {
      return {
        ...baseInfo,
        'Hours': '9:00 AM - 6:00 PM',
        'Admission': 'Free / Paid tours available',
        'Duration': '1-2 hours recommended',
      };
    }
  };

  const showCheckbox = (type === 'hotel' || type === 'landmark' || type === 'event') && onSelect;

  return (
    <>
      <div className={`bg-white rounded-lg overflow-hidden shadow-sm border-2 min-w-[200px] flex flex-col transition-colors ${
        isSelected ? 'border-blue-500' : 'border-gray-200'
      }`}>
        <div className="h-32 bg-gray-200 overflow-hidden relative">
          <img
            src={image}
            alt={title}
            className="w-full h-full object-cover"
          />
          {showCheckbox && (
            <div className="absolute top-2 left-2">
              <div className="relative">
                <input
                  type="checkbox"
                  checked={isSelected}
                  onChange={onSelect}
                  className="appearance-none w-6 h-6 border-2 border-blue-400 rounded cursor-pointer checked:bg-blue-500 checked:border-blue-500 bg-white transition-all shadow-sm"
                />
                {isSelected && (
                  <svg
                    className="absolute top-1 left-1 w-4 h-4 text-white pointer-events-none"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="3"
                  >
                    <path d="M5 13l4 4L19 7" />
                  </svg>
                )}
              </div>
            </div>
          )}
        </div>

        <div className="p-3 flex-1 flex flex-col">
          <h3 className="font-medium text-gray-900 text-sm mb-1">{title}</h3>
          <p className="text-xs text-gray-600 mb-2">{subtitle}</p>

          {date && (
            <p className="text-xs text-gray-500 mb-2">{date}</p>
          )}

          {price !== undefined && (
            <p className="text-pink-600 font-bold mb-2">${price}/{priceLabel}</p>
          )}

          <button
            onClick={handleLearnMore}
            className="mt-auto bg-pink-100 text-pink-600 px-3 py-1.5 rounded text-xs font-medium hover:bg-pink-200 transition-colors"
          >
            Learn More
          </button>
        </div>
      </div>

      {showPopup && (
        <InfoPopup
          title={title}
          info={getMoreInfo()}
          position={popupPosition}
          onClose={() => setShowPopup(false)}
        />
      )}
    </>
  );
}
