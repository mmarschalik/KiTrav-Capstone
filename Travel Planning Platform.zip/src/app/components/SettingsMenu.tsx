import { User, Settings, DollarSign, HelpCircle } from 'lucide-react';
import { useEffect, useRef } from 'react';
import { useNavigate } from 'react-router';
import { useAuth } from '../context/AuthContext';

interface SettingsMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SettingsMenu({ isOpen, onClose }: SettingsMenuProps) {
  const { logout } = useAuth();
  const navigate = useNavigate();
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        onClose();
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleLogout = () => {
    logout();
    onClose();
  };

  return (
    <div
      ref={menuRef}
      className="fixed top-20 right-6 w-72 bg-white rounded-lg shadow-xl border border-gray-200 z-50 py-4"
    >
      {/* Account Options */}
      <div className="px-4 pb-3 border-b border-gray-200">
        <h3 className="text-xs font-semibold text-gray-500 mb-3">Account Options</h3>
        <button
          onClick={() => {
            navigate('/my-account');
            onClose();
          }}
          className="w-full flex items-center gap-3 px-3 py-2 text-gray-700 hover:bg-gray-50 rounded-lg transition-colors"
        >
          <User className="w-5 h-5" />
          <span>My Account</span>
        </button>
        <button
          onClick={() => {
            navigate('/settings');
            onClose();
          }}
          className="w-full flex items-center gap-3 px-3 py-2 text-gray-700 hover:bg-gray-50 rounded-lg transition-colors"
        >
          <Settings className="w-5 h-5" />
          <span>Settings</span>
        </button>
        <button
          onClick={() => {
            navigate('/billing');
            onClose();
          }}
          className="w-full flex items-center gap-3 px-3 py-2 text-gray-700 hover:bg-gray-50 rounded-lg transition-colors"
        >
          <DollarSign className="w-5 h-5" />
          <span>Billing Details</span>
        </button>
      </div>

      {/* Platform */}
      <div className="px-4 py-3 border-b border-gray-200">
        <h3 className="text-xs font-semibold text-gray-500 mb-3">Platform</h3>
        <button className="w-full flex items-center gap-3 px-3 py-2 text-gray-700 hover:bg-gray-50 rounded-lg transition-colors">
          <HelpCircle className="w-5 h-5" />
          <span>Help Center</span>
        </button>
      </div>

      {/* Logout */}
      <div className="px-4 pt-3">
        <button
          onClick={handleLogout}
          className="w-full px-6 py-3 border-2 border-gray-300 text-gray-700 rounded-full font-medium hover:bg-gray-50 transition-colors"
        >
          Logout
        </button>
      </div>
    </div>
  );
}
