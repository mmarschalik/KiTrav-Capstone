import { useEffect, useRef } from 'react';
import { X } from 'lucide-react';

interface InfoPopupProps {
  title: string;
  info: Record<string, string>;
  position: { x: number; y: number };
  onClose: () => void;
}

export function InfoPopup({ title, info, position, onClose }: InfoPopupProps) {
  const popupRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (popupRef.current && !popupRef.current.contains(event.target as Node)) {
        onClose();
      }
    };

    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    document.addEventListener('keydown', handleEscape);

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscape);
    };
  }, [onClose]);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center backdrop-blur-[2px]">
      <div
        ref={popupRef}
        className="bg-white rounded-xl shadow-2xl border-2 border-gray-300 p-6 max-w-md w-full mx-4 animate-in fade-in zoom-in duration-200"
      >
        <div className="flex items-start justify-between mb-4">
          <h3 className="text-xl font-semibold text-gray-900">{title}</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-3">
          {Object.entries(info).map(([key, value]) => (
            <div key={key} className="flex justify-between border-b border-gray-100 pb-2">
              <span className="text-sm font-medium text-gray-600">{key}:</span>
              <span className="text-sm text-gray-900 text-right">{value}</span>
            </div>
          ))}
        </div>

        <button
          onClick={onClose}
          className="mt-6 w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors font-medium"
        >
          Close
        </button>
      </div>
    </div>
  );
}
