import { useState } from 'react';
import { InfoPopup } from './InfoPopup';

interface FlightCardProps {
  airline: string;
  flightNumber: string;
  price: number;
  departureTime: string;
  duration: string;
  stops: string;
  route: string;
  isSelected: boolean;
  onSelect: () => void;
}

export function FlightCard({
  airline,
  flightNumber,
  price,
  departureTime,
  duration,
  stops,
  route,
  isSelected,
  onSelect,
}: FlightCardProps) {
  const [showPopup, setShowPopup] = useState(false);
  const [popupPosition, setPopupPosition] = useState({ x: 0, y: 0 });

  const handleMoreInfo = (e: React.MouseEvent<HTMLButtonElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setPopupPosition({
      x: rect.left + rect.width / 2,
      y: rect.top,
    });
    setShowPopup(true);
  };

  const moreInfo = {
    'Flight Details': `${airline} ${flightNumber}`,
    'Departure': departureTime,
    'Route': route,
    'Duration': duration,
    'Stops': stops,
    'Aircraft': 'Boeing 737-800',
    'Baggage': '1 carry-on, 1 checked bag included',
    'Seat Selection': 'Available for $25',
  };

  return (
    <>
      <div className={`bg-white rounded-lg p-4 shadow-sm border-2 min-w-[240px] flex flex-col transition-colors ${
        isSelected ? 'border-blue-500' : 'border-gray-200'
      }`}>
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-start gap-3">
            <div className="relative mt-1">
              <input
                type="checkbox"
                checked={isSelected}
                onChange={onSelect}
                className="appearance-none w-5 h-5 border-2 border-blue-400 rounded cursor-pointer checked:bg-blue-500 checked:border-blue-500 transition-all"
              />
              {isSelected && (
                <svg
                  className="absolute top-0.5 left-0.5 w-4 h-4 text-white pointer-events-none"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="3"
                >
                  <path d="M5 13l4 4L19 7" />
                </svg>
              )}
            </div>
            <div>
              <h3 className="font-medium text-gray-900">{airline}</h3>
              <p className="text-sm text-gray-600">{flightNumber}</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold text-pink-600">${price}</p>
          </div>
        </div>

        <div className="text-sm text-gray-600 space-y-1 mb-4">
          <p>{departureTime}</p>
          <p className="text-xs">{route}</p>
          <p>{duration} • {stops}</p>
        </div>

        <button
          onClick={handleMoreInfo}
          className="mt-auto bg-pink-100 text-pink-600 px-4 py-2 rounded text-sm font-medium hover:bg-pink-200 transition-colors"
        >
          More Info
        </button>
      </div>

      {showPopup && (
        <InfoPopup
          title={`${airline} - ${flightNumber}`}
          info={moreInfo}
          position={popupPosition}
          onClose={() => setShowPopup(false)}
        />
      )}
    </>
  );
}
