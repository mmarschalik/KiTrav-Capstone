import { useState } from 'react';
import { Settings, Gift } from 'lucide-react';
import { useNavigate } from 'react-router';
import logo from '../../imports/image-0.png';
import { AuthModal } from './AuthModal';
import { SettingsMenu } from './SettingsMenu';
import { useAuth } from '../context/AuthContext';

export function Header() {
  const navigate = useNavigate();
  const { isLoggedIn, username } = useAuth();
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showSettingsMenu, setShowSettingsMenu] = useState(false);

  const navItems = [
    'Home',
    'About',
    'Travel eBook',
    'Booking for Visa',
    'Pricing',
    'Blog',
    'FAQs',
  ];

  return (
    <>
      <header className="w-full">
        {/* Promotional Banner */}
        <div className="bg-blue-700 text-white py-3 px-4 flex items-center justify-center gap-2">
          <Gift className="w-5 h-5" />
          <span>Promotional offer</span>
        </div>

        {/* Main Header */}
        <div className="bg-white border-b border-gray-200 px-6 py-4">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            {/* Logo */}
            <button onClick={() => navigate('/')} className="flex-shrink-0">
              <img src={logo} alt="Kitravia" className="h-10" />
            </button>

            {/* Navigation */}
            <nav className="hidden lg:flex items-center gap-8">
              {navItems.map((item) => (
                <button
                  key={item}
                  className="text-blue-700 hover:text-blue-900 font-medium transition-colors"
                >
                  {item}
                </button>
              ))}
            </nav>

            {/* Right Side Actions */}
            <div className="flex items-center gap-4">
              {isLoggedIn ? (
                <>
                  <button
                    onClick={() => setShowSettingsMenu(!showSettingsMenu)}
                    className="flex items-center gap-2 text-blue-700 hover:text-blue-900"
                  >
                    <Settings className="w-5 h-5" />
                    <span className="font-medium">{username}</span>
                  </button>
                  <button
                    onClick={() => navigate('/')}
                    className="px-6 py-2 border-2 border-blue-600 text-blue-600 rounded-lg font-medium hover:bg-blue-50 transition-colors"
                  >
                    Plan Your Trip
                  </button>
                </>
              ) : (
                <>
                  <button
                    onClick={() => setShowAuthModal(true)}
                    className="px-6 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors"
                  >
                    Log in
                  </button>
                  <button
                    onClick={() => navigate('/')}
                    className="px-6 py-2 border-2 border-blue-600 text-blue-600 rounded-lg font-medium hover:bg-blue-50 transition-colors"
                  >
                    Plan Your Trip
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Auth Modal */}
      <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />

      {/* Settings Menu */}
      {isLoggedIn && (
        <SettingsMenu isOpen={showSettingsMenu} onClose={() => setShowSettingsMenu(false)} />
      )}
    </>
  );
}
