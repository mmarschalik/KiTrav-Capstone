import { BrowserRouter, Routes, Route } from 'react-router';
import { Home } from './pages/Home';
import { SearchResults } from './pages/SearchResults';
import { Checkout } from './pages/Checkout';
import { Confirmation } from './pages/Confirmation';
import { MyAccount } from './pages/MyAccount';
import { Settings } from './pages/Settings';
import { BillingDetails } from './pages/BillingDetails';
import { AuthProvider } from './context/AuthContext';

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/search" element={<SearchResults />} />
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/confirmation" element={<Confirmation />} />
          <Route path="/my-account" element={<MyAccount />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/billing" element={<BillingDetails />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}